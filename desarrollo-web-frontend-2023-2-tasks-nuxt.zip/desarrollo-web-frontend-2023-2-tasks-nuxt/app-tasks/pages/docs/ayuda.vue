<template>
  <div>
    <h1>Página de ayuda</h1>
  </div>
</template>