<template>
  <div class="ma-5">
 
    <TasksCreateDialog />

    <TasksTable />


  </div>
</template>
