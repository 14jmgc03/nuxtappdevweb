<template>
  <div>
    
    <!-- slot: Carga el contenido de la página (pages/..) -->
    <slot />

  </div>
</template>